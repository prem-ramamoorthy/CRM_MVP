import { NavLink, Outlet, useLocation } from "react-router-dom";
import { Building2, KanbanSquare, LayoutDashboard, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { ProductTour } from "@/components/onboarding/ProductTour";
import { HelpButton } from "@/components/onboarding/HelpButton";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true, tour: "nav-dashboard" },
  { to: "/leads", label: "Leads", icon: Users, tour: "nav-leads" },
  { to: "/pipeline", label: "Pipeline", icon: KanbanSquare, tour: "nav-pipeline" },
];

export function AppLayout() {
  const { pathname } = useLocation();
  return (
    <div className="min-h-screen flex w-full bg-gradient-subtle relative">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-[0.35]" aria-hidden />
      <aside className="hidden md:flex w-64 shrink-0 flex-col border-r bg-sidebar/80 backdrop-blur-xl relative z-10">
        <div className="flex h-16 items-center gap-2 px-6 border-b">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-primary text-primary-foreground shadow-elegant-md transition-transform hover:scale-105">
            <Building2 className="h-5 w-5" />
          </div>
          <div>
            <p className="font-semibold text-sidebar-foreground leading-tight">NestCRM</p>
            <p className="text-xs text-muted-foreground">PG Lead Management</p>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1 max-h-[80dvh]">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              data-tour={item.tour}
              className={({ isActive }) =>
                cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 relative",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-elegant-sm"
                    : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:translate-x-0.5",
                )
              }
            >
              <item.icon className="h-4 w-4 transition-transform group-hover:scale-110" />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t fixed bottom-0 left-0 w-64 bg-sidebar/80 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-gradient-primary text-primary-foreground inline-flex items-center justify-center text-sm font-semibold md:z-20 md:shadow-elegant-md">AS</div>
            <div className="text-sm">
              <p className="font-medium text-sidebar-foreground">Aarav Sharma</p>
              <p className="text-xs text-muted-foreground">Admin</p>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        <header className="md:hidden h-14 flex items-center gap-3 border-b px-4 bg-background/80 backdrop-blur-md">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-primary text-primary-foreground">
            <Building2 className="h-4 w-4" />
          </div>
          <p className="font-semibold">NestCRM</p>
        </header>
        <nav className="md:hidden flex border-b bg-background/80 backdrop-blur-md overflow-x-auto">
          {nav.map((item) => {
            const active = item.end ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <NavLink key={item.to} to={item.to} end={item.end} data-tour={item.tour}
                className={cn("flex items-center gap-2 px-4 py-3 text-sm whitespace-nowrap border-b-2 transition-colors",
                  active ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground")}>
                <item.icon className="h-4 w-4" />{item.label}
              </NavLink>
            );
          })}
        </nav>
        <main key={pathname} className="flex-1 p-4 md:p-8 animate-fade-in-up">
          <Outlet />
        </main>
      </div>
      <ProductTour />
      <HelpButton />
    </div>
  );
}