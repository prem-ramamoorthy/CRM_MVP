import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "./pages/NotFound.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Leads from "./pages/Leads.tsx";
import LeadDetail from "./pages/LeadDetail.tsx";
import Pipeline from "./pages/Pipeline.tsx";
import { AppLayout } from "./components/layout/AppLayout";
import { CrmProvider } from "./store/crmStore";
import { OnboardingProvider } from "./store/onboardingStore";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <CrmProvider>
        <BrowserRouter>
          <OnboardingProvider>
            <Routes>
              <Route element={<AppLayout />}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/leads" element={<Leads />} />
                <Route path="/leads/:id" element={<LeadDetail />} />
                <Route path="/pipeline" element={<Pipeline />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </OnboardingProvider>
        </BrowserRouter>
      </CrmProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
